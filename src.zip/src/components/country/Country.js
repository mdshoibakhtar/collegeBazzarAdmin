import CountryList from "./countryList/CountryList"

function Country() {
    return (
        <>
            <CountryList />
        </>
    )
}
export default Country