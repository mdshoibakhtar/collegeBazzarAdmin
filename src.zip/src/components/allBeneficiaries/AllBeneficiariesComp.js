import React from 'react'

function AllBeneficiariesComp() {
    return (
        <div>AllBeneficiariesComp</div>
    )
}

export default AllBeneficiariesComp