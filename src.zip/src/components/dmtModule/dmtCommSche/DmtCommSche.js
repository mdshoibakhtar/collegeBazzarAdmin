import React from 'react'
import Breadcrumbs from '../../../common/breadcrumb/Breadcrumbs'
import DmtcommschList from './dmtcommschList/DmtcommschList'

function DmtCommSche() {
 
  return (
    <>
    <Breadcrumbs breadCrumbsTitle={""}/>
    <DmtcommschList/>
    </>

  )
}

export default DmtCommSche