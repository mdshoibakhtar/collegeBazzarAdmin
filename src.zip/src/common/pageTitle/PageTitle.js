import Breadcrums from "../breadcrumb/Breadcrumbs";


function PageTitle() {
    return (
        <>
            {/* <Breadcrums/> */}
        </>
    )
}
export default PageTitle